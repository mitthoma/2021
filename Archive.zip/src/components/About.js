import React from 'react';
import Layout from './Layout';
import { animated, useSpring } from 'react-spring';

function Blog() {

  return(
    <div>

    <Layout />
      <h1>about</h1>
      <h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1><h1>about</h1>
    </div>
  )
}

export default Blog;
